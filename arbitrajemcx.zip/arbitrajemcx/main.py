# main.py

import time
import ccxt
import requests
import csv
import os
from datetime import datetime
from config import BINANCE_API_KEY, BINANCE_API_SECRET, BYBIT_API_KEY, BYBIT_API_SECRET, TELEGRAM_TOKEN, TELEGRAM_CHAT_ID

binance = ccxt.binance({ 'apiKey': BINANCE_API_KEY, 'secret': BINANCE_API_SECRET, 'enableRateLimit': True })
bybit = ccxt.bybit({ 'apiKey': BYBIT_API_KEY, 'secret': BYBIT_API_SECRET, 'enableRateLimit': True })

symbols = ['ETH/USDT', 'SOL/USDT', 'XRP/USDT']
spread_threshold = 0.0075
last_alert = {}

def send_telegram(message):
    url = f"https://api.telegram.org/bot{TELEGRAM_TOKEN}/sendMessage"
    payload = { "chat_id": TELEGRAM_CHAT_ID, "text": message }
    try:
        requests.post(url, json=payload)
    except Exception as e:
        print(f"❌ Error al enviar mensaje a Telegram: {e}")

def log_to_csv(data):
    filename = "arbitraje_log.csv"
    file_exists = os.path.isfile(filename)
    with open(filename, 'a', newline='') as csvfile:
        writer = csv.writer(csvfile)
        if not file_exists:
            writer.writerow(["Timestamp", "Par", "Precio Binance", "Precio Bybit", "Spread", "Mensaje"])
        writer.writerow(data)

def get_prices(symbol):
    try:
        price_binance = binance.fetch_ticker(symbol)['last']
        price_bybit = bybit.fetch_ticker(symbol)['last']
        return price_binance, price_bybit
    except Exception as e:
        print(f"❌ Error al obtener precios: {e}")
        return None, None

def check_arbitrage():
    for symbol in symbols:
        price_binance, price_bybit = get_prices(symbol)
        if price_binance and price_bybit:
            spread = abs(price_binance - price_bybit) / ((price_binance + price_bybit) / 2)
            message = f"{symbol} — Binance: {price_binance:.4f} | Bybit: {price_bybit:.4f} | Spread: {spread:.4%}"
            print(message)

            if spread > spread_threshold:
                action = ""
                if price_binance < price_bybit:
                    action = f"🔁 Comprar en Binance y vender en Bybit ({symbol})"
                else:
                    action = f"🔁 Comprar en Bybit y vender en Binance ({symbol})"

                full_message = f"{message}\n{action}"

                if symbol not in last_alert or time.time() - last_alert[symbol] > 300:
                    send_telegram(full_message)
                    last_alert[symbol] = time.time()

                log_to_csv([datetime.now(), symbol, price_binance, price_bybit, f"{spread:.4%}", action])
        else:
            print(f"❌ No se pudieron obtener precios para {symbol}")

while True:
    check_arbitrage()
    time.sleep(15)
