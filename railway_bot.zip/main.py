from config import *
import ccxt
import time

bybit = ccxt.bybit({
    'apiKey': bybit_api_key,
    'secret': bybit_api_secret
})

coinex = ccxt.coinex({
    'apiKey': coinex_api_key,
    'secret': coinex_api_secret
})

while True:
    try:
        price_bybit = bybit.fetch_ticker('ETH/USDT')['last']
        price_coinex = coinex.fetch_ticker('ETH/USDT')['last']
        print("Bybit:", price_bybit, "CoinEx:", price_coinex)
    except Exception as e:
        print("Error:", e)
    time.sleep(10)