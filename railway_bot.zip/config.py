bybit_api_key = "TU_API_KEY_BYBIT"
bybit_api_secret = "TU_SECRET_BYBIT"

coinex_api_key = "TU_API_KEY_COINEX"
coinex_api_secret = "TU_SECRET_COINEX"